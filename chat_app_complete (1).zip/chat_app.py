from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory
from flask_socketio import SocketIO, join_room, leave_room, emit
import os
import bcrypt
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'your_secret_key'
socketio = SocketIO(app, cors_allowed_origins="*")

# Kullanıcı ve mesaj verisi (basit örnek için bellekte)
users = {}
messages = {}
uploads_folder = 'uploads'
os.makedirs(uploads_folder, exist_ok=True)

# Basit kullanıcı yönetimi
def current_user():
    username = session.get('username')
    if username and username in users:
        return username
    return None

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password'].encode('utf-8')
        if username in users:
            return "Kullanıcı zaten var"
        hashed = bcrypt.hashpw(password, bcrypt.gensalt())
        users[username] = hashed
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password'].encode('utf-8')
        if username in users and bcrypt.checkpw(password, users[username]):
            session['username'] = username
            return redirect(url_for('chat'))
        return "Giriş başarısız"
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/')
def home():
    return redirect(url_for('chat'))

@app.route('/chat')
def chat():
    user = current_user()
    if not user:
        return redirect(url_for('login'))
    user_list = list(users.keys())
    user_list.remove(user)
    return render_template('chat.html', username=user, users=user_list)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(uploads_folder, filename)

# WebSocket Events
@socketio.on('join')
def on_join(data):
    room = data['room']
    join_room(room)
    emit('status', {'msg': f"{data['username']} odaya katıldı."}, room=room)

@socketio.on('leave')
def on_leave(data):
    room = data['room']
    leave_room(room)
    emit('status', {'msg': f"{data['username']} odadan ayrıldı."}, room=room)

@socketio.on('send_message')
def handle_message(data):
    room = data['room']
    msg = data['msg']
    username = data['username']
    if room not in messages:
        messages[room] = []
    messages[room].append({'username': username, 'msg': msg})
    emit('receive_message', {'username': username, 'msg': msg}, room=room)

@socketio.on('send_file')
def handle_file(data):
    # Bu örnek basit; gerçek dosya transferi için farklı yöntem gerekebilir
    room = data['room']
    filename = data['filename']
    username = data['username']
    emit('receive_file', {'username': username, 'filename': filename}, room=room)


from flask import jsonify

@app.route('/upload', methods=['POST'])
def upload_file():
    user = current_user()
    if not user:
        return jsonify({'success': False, 'error': 'Giriş yapmalısınız'})
    if 'file' not in request.files:
        return jsonify({'success': False, 'error': 'Dosya bulunamadı'})
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'Dosya seçilmedi'})
    filename = secure_filename(file.filename)
    file.save(os.path.join(uploads_folder, filename))
    return jsonify({'success': True, 'filename': filename})


if __name__ == '__main__':
    socketio.run(app, debug=True)
