# Okul Sohbet Uygulaması

Python Flask + SocketIO ile geliştirilmiş okul sınıfı sohbet uygulaması.

## Özellikler
- Kullanıcı kayıt/giriş
- Özel mesajlaşma
- Dosya yükleme

## Kurulum

```bash
git clone https://github.com/kullaniciadi/proje.git
cd proje
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
mkdir uploads
python chat_app.py
```

## Deploy

- Sunucuda Python 3, pip, nginx kurulu olmalı
- `uploads/` klasörü yazılabilir olmalı
- Gunicorn + eventlet ile çalıştır:
  ```bash
  gunicorn --worker-class eventlet -w 1 -b 0.0.0.0:5000 chat_app:app
  ```
- Nginx ile ters proxy ayarla (WebSocket destekli)
